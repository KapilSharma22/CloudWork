import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SecurePassUI';
  showAuthUserForm = false;

  ShowComponent = function(val){
    if(val == 1)
      this.showAuthUserForm = false;
    if(val == 2)
      this.showAuthUserForm = true;
  }
}

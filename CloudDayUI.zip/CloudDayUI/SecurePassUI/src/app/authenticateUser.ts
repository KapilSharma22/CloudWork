import { Component } from '@angular/core';
import { WebCamComponent } from 'ack-angular-webcam';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import {UploadFileService} from './uploadService'

@Component({
  selector: 'authenticate-user',
  templateUrl: './authenticateuser.html',
  styleUrls: ['./addEmployee.css']
})
export class AuthUserComponent {
    options = [];
  title = 'Authenticate User';
  FOLDER = 'jsa-s3/';
  msg = '';
  isMsgDisplay = false;

  constructor(private uploadService: UploadFileService) { }
  ngOnInit() {
}
  onCamSuccess = function(val){
  }

  onCamError= function(val){
  }

  AuthenticateUser = function(webcam:WebCamComponent)
  {
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    var fname:string  = 'RBS_' + random + '.png';
    debugger;
    webcam.getFile(fname)
    .then( imgData=>this.uploadfile(imgData) )
    .catch(err=>console.log(err));
  }

  uploadfile(file) {
    debugger;
    const bucket = new S3(
      {
        accessKeyId: 'AKIAXIAPBJGCHEGMLX4H',
        secretAccessKey: '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',
        region: 'eu-west-1'
      }
    );
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    let fname = 'RBS_' + random + '.png';
    const params = {
      Bucket: 'facerecognitionfiles',
      Key: this.FOLDER + fname,
      Body: file,
      ACL: 'public-read'
    };
 
    bucket.upload(params, function (err, data) {
      if (err) {
        console.log('There was an error uploading your file: ', err);
        this.isMsgDisplay = true;
        this.msg = "Some error occured in the authentication process."
        return false;
      }
      this.isMsgDisplay = true;
      console.log('Successfully uploaded file.', data);
      this.msg = "Action is successfull and result will be send via email."
      return true;
    });
  }
}

import { Component } from '@angular/core';
import { WebCamComponent } from 'ack-angular-webcam';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import {UploadFileService} from './uploadService'

@Component({
  selector: 'add-employee',
  templateUrl: './addEmployee.html',
  styleUrls: ['./addEmployee.css']
})
export class addEmpComponent {
  title = 'SecurePassUI';
  FOLDER = 'jsa-s3/';
  options = [];
    isMsgDisplay = false;
   msg = '';

  constructor(private uploadService: UploadFileService) { }
  ngOnInit() {
}
  onCamSuccess = function(val){

  }

  onCamError= function(val){

  }

  //submitRequest = function(webcam:WebCamComponent)
  submitRequest = function(webcam)
  {
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    var fname:string  = 'RBS_' + random + '.png';
    debugger;
    webcam.getFile(fname)
    .then(formdata=>this.uploadfile(formdata) )
    .catch(err=>console.log(err));
  }

  uploadfile(file) {
    debugger;
    const bucket = new S3(
      {
        accessKeyId: 'AKIAXIAPBJGCHEGMLX4H',
        secretAccessKey: '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',
        region: 'eu-west-1'
      }
    );
    let random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    let fname = 'RBS_' + random + '.png';
    const params = {
      Bucket: 'employeeimages-demo',
      Key: this.FOLDER + fname,
      Body: file,
      ACL: 'public-read'
    };
 
    bucket.upload(params, function (err, data) {
      if (err) {
        console.log('There was an error uploading your file: ', err);
        this.isMsgDisplay = true;
        this.msg = 'Some error occurred in this process.';
        return false;
      }
      debugger;
      this.isMsgDisplay = true;
      this.msg = 'Employee record has been successfully uploaded.';
      console.log('Successfully uploaded file.', data);
      return true;
    });
  }
}

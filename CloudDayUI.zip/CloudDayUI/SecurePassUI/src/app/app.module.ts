import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { addEmpComponent } from './addEmployee';
import { WebCamModule } from 'ack-angular-webcam';
import { UploadFileService } from './uploadService';
import {AuthUserComponent} from './authenticateUser';

@NgModule({
  declarations: [
    AppComponent,
    addEmpComponent,
    AuthUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    WebCamModule
  ],
  providers: [UploadFileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
